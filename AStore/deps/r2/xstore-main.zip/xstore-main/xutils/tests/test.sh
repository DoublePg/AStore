#!/usr/bin/env sh

./test_rtm

#!/usr/bin/env bash
scp wxd@val02:/cock/xstore/ne.py .
scp wxd@val02:/cock/xstore/cdf.py .
scp wxd@val02:/cock/xstore/trained.py .
scp wxd@val02:/cock/xstore/feature.py .

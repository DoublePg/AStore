#pragma once

#include "../../xutils/cdf.hh"

namespace xstore {

namespace xcache {

struct Statics {
  // TODO: not implemented

  // 1. error
  // 2. average model responsible num
  // 3. todo
};

} // namespace xcache
} // namespace xstore

#include "../src/transport/rdma_ud_t.hh"

#include <iostream>

int main() { std::cout << "hello world!"; }
